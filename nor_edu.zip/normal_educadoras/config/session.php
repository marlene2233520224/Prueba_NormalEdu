<?php
session_start();

function requireLogin() {
    if (!isset($_SESSION['user'])) {
        header('Location: ../index.php');
        exit();
    }
}

function requireLogout() {
    if (isset($_SESSION['user'])) {
        header('Location: ../controllers/DashboardController.php');
        exit();
    }
}

function logout() {
    session_destroy();
}
?>