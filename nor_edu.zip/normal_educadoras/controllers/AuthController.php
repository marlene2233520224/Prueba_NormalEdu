<?php
// controllers/AuthController.php
session_start();

// Si se llama a logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_destroy();
    header('Location: ../index.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario = trim($_POST['usuario']);
    $contrasena = trim($_POST['contrasena']);

    // Simulación de login
    $mockUsers = [
        ['usuario' => 'admin', 'contrasena' => '123456', 'rol' => 'admin'],
        ['usuario' => 'docente', 'contrasena' => 'docente123', 'rol' => 'docente']
    ];

    $logueado = false;
    foreach ($mockUsers as $user) {
        if ($user['usuario'] === $usuario && $user['contrasena'] === $contrasena) {
            $_SESSION['user'] = $user;
            $logueado = true;
            break;
        }
    }

    if ($logueado) {
        header('Location: DashboardController.php');
        exit();
    } else {
        $_SESSION['error'] = "Usuario o contraseña incorrectos.";
        header('Location: ../index.php');
        exit();
    }
} else {
    header('Location: ../index.php');
    exit();
}
?>