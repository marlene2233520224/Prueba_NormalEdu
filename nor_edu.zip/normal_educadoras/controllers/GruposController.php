<?php
session_start();

// Si no está logueado, redirige al login
if (!isset($_SESSION['user'])) {
    header('Location: ../index.php');
    exit();
}

// Acción por defecto
$action = $_GET['action'] ?? 'index';

switch ($action) {
    case 'index':
        include '../views/grupos/index.php';
        break;
    case 'create':
        // Aquí iría la lógica para crear un grupo
        include '../views/grupos/create.php';
        break;
    case 'edit':
        // Aquí iría la lógica para editar un grupo
        include '../views/grupos/edit.php';
        break;
    case 'delete':
        // Aquí iría la lógica para eliminar un grupo
        header('Location: index.php');
        break;
    default:
        include '../views/grupos/index.php';
}
?>