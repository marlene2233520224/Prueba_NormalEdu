<?php
require_once '../config/session.php';
requireLogin();

require_once '../config/database.php';
$database = new Database();
$conn = $database->getConnection();

$action = $_GET['action'] ?? 'index';

switch ($action) {
    case 'index':
        include '../views/horarios/index.php';
        break;
        
    case 'asignar':
        include '../views/horarios/asignar.php';
        break;
        
    case 'check_duplicate_master':
        checkDuplicateMaster();
        break;
        
    case 'insert_master':
        insertMaster();
        break;
        
    case 'insert_detail':
        insertDetail();
        break;
        
    default:
        include '../views/horarios/index.php';
}

function checkDuplicateMaster() {
    global $conn;
    
    header('Content-Type: application/json');
    
    try {
        $id_ciclo_escolar = $_POST['id_ciclo_escolar'] ?? 0;
        $id_plan_estudio = $_POST['id_plan_estudio'] ?? 0;
        $clave_docente = $_POST['clave_docente'] ?? '';
        $clave_asignatura = $_POST['clave_asignatura'] ?? '';
        $grado = $_POST['grado'] ?? 0;
        $grupo = $_POST['grupo'] ?? '';

        $sql = "SELECT id_asignacion 
                FROM ctrl_asignacion 
                WHERE id_ciclo_escolar = :id_ciclo_escolar
                AND id_plan_estudio = :id_plan_estudio
                AND clave_docente = :clave_docente
                AND clave_asignatura = :clave_asignatura
                AND grado = :grado
                AND grupo = :grupo
                AND id_status = 1
                LIMIT 1";
        
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_ciclo_escolar', $id_ciclo_escolar);
        $stmt->bindParam(':id_plan_estudio', $id_plan_estudio);
        $stmt->bindParam(':clave_docente', $clave_docente);
        $stmt->bindParam(':clave_asignatura', $clave_asignatura);
        $stmt->bindParam(':grado', $grado);
        $stmt->bindParam(':grupo', $grupo);
        $stmt->execute();
        
        if ($stmt->rowCount() > 0) {
            $row = $stmt->fetch(PDO::FETCH_ASSOC);
            echo json_encode([
                'exists' => true,
                'message' => 'Ya existe; se cargó la asignación.',
                'id_asignacion' => $row['id_asignacion']
            ]);
        } else {
            echo json_encode([
                'exists' => false,
                'message' => 'No hay duplicados'
            ]);
        }
        
    } catch (Exception $e) {
        error_log("Error en checkDuplicateMaster: " . $e->getMessage());
        echo json_encode([
            'exists' => false,
            'message' => 'Error en la validación'
        ]);
    }
    exit;
}

function insertMaster() {
    global $conn;
    
    header('Content-Type: application/json');
    
    try {
        $id_ciclo_escolar = $_POST['id_ciclo_escolar'] ?? 0;
        $id_plan_estudio = $_POST['id_plan_estudio'] ?? 0;
        $clave_docente = $_POST['clave_docente'] ?? '';
        $clave_asignatura = $_POST['clave_asignatura'] ?? '';
        $grado = $_POST['grado'] ?? 0;
        $grupo = $_POST['grupo'] ?? '';
        
        $sql = "INSERT INTO ctrl_asignacion 
                (id_ciclo_escolar, id_plan_estudio, clave_docente, clave_asignatura, 
                 grado, grupo, id_status, id_usuario, fec_actualiza) 
                VALUES 
                (:id_ciclo_escolar, :id_plan_estudio, :clave_docente, :clave_asignatura, 
                 :grado, :grupo, 1, 1, CURRENT_TIMESTAMP)";
        
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':id_ciclo_escolar', $id_ciclo_escolar);
        $stmt->bindParam(':id_plan_estudio', $id_plan_estudio);
        $stmt->bindParam(':clave_docente', $clave_docente);
        $stmt->bindParam(':clave_asignatura', $clave_asignatura);
        $stmt->bindParam(':grado', $grado);
        $stmt->bindParam(':grupo', $grupo);
        
        if ($stmt->execute()) {
            $id_asignacion = $conn->lastInsertId();
            echo json_encode([
                'success' => true,
                'message' => 'Maestro insertado correctamente',
                'id_asignacion' => $id_asignacion
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Error al insertar maestro'
            ]);
        }
        
    } catch (Exception $e) {
        error_log("Error en insertMaster: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'Error en la inserción del maestro'
        ]);
    }
    exit;
}

function insertDetail() {
    global $conn;
    
    header('Content-Type: application/json');
    
    try {
        $id_asignacion = $_POST['id_asignacion'] ?? 0;
        $id_hora = $_POST['id_hora'] ?? 0;
        $dia_semana = $_POST['dia_semana'] ?? '';
        
        if ($id_asignacion <= 0 || $id_hora <= 0 || empty($dia_semana)) {
            echo json_encode([
                'success' => false,
                'message' => 'Parámetros incompletos'
            ]);
            return;
        }
        
        $sqlCheckMaster = "SELECT ca.id_asignacion, ca.id_ciclo_escolar, ca.clave_docente, ca.grado, ca.grupo 
                          FROM ctrl_asignacion ca
                          WHERE ca.id_asignacion = :id_asignacion AND ca.id_status = 1";
        $stmtCheck = $conn->prepare($sqlCheckMaster);
        $stmtCheck->bindParam(':id_asignacion', $id_asignacion);
        $stmtCheck->execute();
        
        if ($stmtCheck->rowCount() === 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Maestro no encontrado'
            ]);
            return;
        }
        
        $masterData = $stmtCheck->fetch(PDO::FETCH_ASSOC);
        $id_ciclo_escolar = $masterData['id_ciclo_escolar'];
        $clave_docente = $masterData['clave_docente'];
        $grado = $masterData['grado'];
        $grupo = $masterData['grupo'];
        
        $sqlCheckDetail = "SELECT id_asignacion_detalle FROM ctrl_asignacion_detalle2 
                          WHERE id_asignacion = :id_asignacion 
                          AND id_hora = :id_hora 
                          AND dia_semana = :dia_semana 
                          AND id_status = 1";
        $stmtCheckDetail = $conn->prepare($sqlCheckDetail);
        $stmtCheckDetail->bindParam(':id_asignacion', $id_asignacion);
        $stmtCheckDetail->bindParam(':id_hora', $id_hora);
        $stmtCheckDetail->bindParam(':dia_semana', $dia_semana);
        $stmtCheckDetail->execute();
        
        if ($stmtCheckDetail->rowCount() > 0) {
            $row = $stmtCheckDetail->fetch(PDO::FETCH_ASSOC);
            $id_detalle = $row['id_asignacion_detalle'];
            
            $sqlDelete = "DELETE FROM ctrl_asignacion_detalle2 WHERE id_asignacion_detalle = :id_detalle";
            $stmtDelete = $conn->prepare($sqlDelete);
            $stmtDelete->bindParam(':id_detalle', $id_detalle);
            
            if ($stmtDelete->execute()) {
                echo json_encode([
                    'success' => true,
                    'message' => 'Horario eliminado',
                    'mode' => 'deleted'
                ]);
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'Error al eliminar horario existente'
                ]);
            }
            return;
        }
        
        $sqlDocenteConflict = "SELECT COUNT(*) as count 
                              FROM ctrl_asignacion a
                              JOIN ctrl_asignacion_detalle2 d ON a.id_asignacion = d.id_asignacion
                              WHERE a.id_ciclo_escolar = :id_ciclo_escolar
                              AND a.clave_docente = :clave_docente
                              AND d.id_hora = :id_hora
                              AND d.dia_semana = :dia_semana
                              AND a.id_status = 1
                              AND d.id_status = 1
                              AND a.id_asignacion != :id_asignacion_exclude";
        
        $stmtDocente = $conn->prepare($sqlDocenteConflict);
        $stmtDocente->bindParam(':id_ciclo_escolar', $id_ciclo_escolar);
        $stmtDocente->bindParam(':clave_docente', $clave_docente);
        $stmtDocente->bindParam(':id_hora', $id_hora);
        $stmtDocente->bindParam(':dia_semana', $dia_semana);
        $stmtDocente->bindParam(':id_asignacion_exclude', $id_asignacion);
        $stmtDocente->execute();
        
        $docenteResult = $stmtDocente->fetch(PDO::FETCH_ASSOC);
        
        if ($docenteResult['count'] > 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Conflicto: el docente ya tiene una asignación en ese día y hora (mismo ciclo).'
            ]);
            return;
        }
        
        $sqlGrupoConflict = "SELECT COUNT(*) as count 
                            FROM ctrl_asignacion a
                            JOIN ctrl_asignacion_detalle2 d ON a.id_asignacion = d.id_asignacion
                            WHERE a.id_ciclo_escolar = :id_ciclo_escolar
                            AND a.grado = :grado
                            AND a.grupo = :grupo
                            AND d.id_hora = :id_hora
                            AND d.dia_semana = :dia_semana
                            AND a.id_status = 1
                            AND d.id_status = 1
                            AND a.id_asignacion != :id_asignacion_exclude";
        
        $stmtGrupo = $conn->prepare($sqlGrupoConflict);
        $stmtGrupo->bindParam(':id_ciclo_escolar', $id_ciclo_escolar);
        $stmtGrupo->bindParam(':grado', $grado);
        $stmtGrupo->bindParam(':grupo', $grupo);
        $stmtGrupo->bindParam(':id_hora', $id_hora);
        $stmtGrupo->bindParam(':dia_semana', $dia_semana);
        $stmtGrupo->bindParam(':id_asignacion_exclude', $id_asignacion);
        $stmtGrupo->execute();
        
        $grupoResult = $stmtGrupo->fetch(PDO::FETCH_ASSOC);
        
        if ($grupoResult['count'] > 0) {
            echo json_encode([
                'success' => false,
                'message' => 'Conflicto: el grupo ya tiene una asignación en ese día y hora (mismo ciclo).'
            ]);
            return;
        }
        
        $sqlInsert = "INSERT INTO ctrl_asignacion_detalle2 
                     (id_asignacion, id_hora, dia_semana, id_status, id_usuario, fec_actualiza) 
                     VALUES 
                     (:id_asignacion, :id_hora, :dia_semana, 1, 1, NOW())";
        
        $stmtInsert = $conn->prepare($sqlInsert);
        $stmtInsert->bindParam(':id_asignacion', $id_asignacion);
        $stmtInsert->bindParam(':id_hora', $id_hora);
        $stmtInsert->bindParam(':dia_semana', $dia_semana);
        
        if ($stmtInsert->execute()) {
            echo json_encode([
                'success' => true,
                'message' => 'Horario asignado correctamente',
                'mode' => 'inserted'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Error al asignar horario'
            ]);
        }
        
    } catch (Exception $e) {
        error_log("Error en insertDetail: " . $e->getMessage());
        echo json_encode([
            'success' => false,
            'message' => 'Error en la inserción del detalle'
        ]);
    }
    exit;
}
?>