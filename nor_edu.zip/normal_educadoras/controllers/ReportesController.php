<?php
session_start();

if (!isset($_SESSION['user'])) {
    header('Location: ../index.php');
    exit();
}

$action = $_GET['action'] ?? 'index';

switch ($action) {
    case 'docente':
        include '../views/reportes/reporte-docente.php';
        break;
    case 'grupo':
        include '../views/reportes/reporte-grupo.php';
        break;
    default:
        include '../views/reportes/seleccion-reporte.php';
}
?>