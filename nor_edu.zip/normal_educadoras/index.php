<?php
session_start();

if (isset($_SESSION['user'])) {
    header('Location: controllers/DashboardController.php');
    exit();
}

$error = isset($_SESSION['error']) ? $_SESSION['error'] : null;

include 'views/auth/login.php';

if (isset($_SESSION['error'])) {
    unset($_SESSION['error']);
}
?>