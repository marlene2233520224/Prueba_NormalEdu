<?php
class User {
    private $conn;
    private $table = 'usuarios';

    public $id;
    public $usuario;
    public $contrasena;
    public $rol;

    public function __construct($db) {
        $this->conn = $db;
    }

    public function login($usuario, $contrasena) {
        $mockUsers = [
            ['usuario' => 'admin', 'contrasena' => '123456', 'rol' => 'admin'],
            ['usuario' => 'docente', 'contrasena' => 'docente123', 'rol' => 'docente']
        ];

        foreach ($mockUsers as $user) {
            if ($user['usuario'] === $usuario && $user['contrasena'] === $contrasena) {
                $_SESSION['user'] = $user;
                return true;
            }
        }
        return false;
    }

    public function getRole() {
        return isset($_SESSION['user']) ? $_SESSION['user']['rol'] : 'guest';
    }

    public function isLoggedIn() {
        return isset($_SESSION['user']);
    }
}
?>