document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('asignarForm');
            const conflictAlert = document.getElementById('conflictAlert');
            const inputs = document.querySelectorAll('.form-control');
            const horarioSelect = document.getElementById('horario');
            
            let currentAssignmentId = null;
            let isDuplicateMaster = false;
            
            inputs.forEach(input => {
                input.addEventListener('input', function() {
                    validateField(this);
                    if (this.id !== 'dia' && this.id !== 'horario') {
                        checkDuplicateMaster();
                    }
                });
                
                input.addEventListener('change', function() {
                    validateField(this);
                    if (this.id !== 'dia' && this.id !== 'horario') {
                        checkDuplicateMaster();
                    }
                });
            });
            
            function validateField(field) {
                if (field.value.trim() !== '') {
                    field.classList.add('valid');
                    field.style.borderColor = '#10b981';
                } else {
                    field.classList.remove('valid');
                    field.style.borderColor = '';
                }
            }
            
            function validateMasterRequiredFields() {
                const errors = [];
                
                const ciclo_escolar = document.getElementById('ciclo_escolar').value;
                const plan_estudio = document.getElementById('plan_estudio').value;
                const docente = document.getElementById('docente').value;
                const asignatura = document.getElementById('asignatura').value;
                const grado = document.getElementById('grado').value;
                const grupo = document.getElementById('grupo').value;
                
                if (!ciclo_escolar || ciclo_escolar <= 0) {
                    errors.push('Selecciona ciclo escolar.');
                }
                if (!plan_estudio || plan_estudio <= 0) {
                    errors.push('Selecciona plan de estudio.');
                }
                if (!docente || docente === '') {
                    errors.push('Selecciona docente.');
                }
                if (!asignatura || asignatura === '') {
                    errors.push('Selecciona asignatura.');
                }
                if (!grado || grado <= 0) {
                    errors.push('Selecciona grado.');
                }
                if (!grupo || grupo === '') {
                    errors.push('Selecciona grupo.');
                }
                
                return errors;
            }
            
            function validateDetailRequiredFields() {
                const errors = [];
                
                const dia = document.getElementById('dia').value;
                const horario = document.getElementById('horario').value;
                
                if (!dia || dia === '') {
                    errors.push('Selecciona día.');
                }
                if (!horario || horario <= 0) {
                    errors.push('Selecciona horario.');
                }
                
                return errors;
            }
            
            async function checkDuplicateMaster() {
                const ciclo_escolar = document.getElementById('ciclo_escolar').value;
                const plan_estudio = document.getElementById('plan_estudio').value;
                const docente = document.getElementById('docente').value;
                const asignatura = document.getElementById('asignatura').value;
                const grado = document.getElementById('grado').value;
                const grupo = document.getElementById('grupo').value;
                
                if (!ciclo_escolar || !plan_estudio || !docente || !asignatura || !grado || !grupo) {
                    return false;
                }
                
                try {
                    const response = await fetch('../../controllers/HorariosController.php?action=check_duplicate_master', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: new URLSearchParams({
                            id_ciclo_escolar: ciclo_escolar,
                            id_plan_estudio: plan_estudio,
                            clave_docente: docente,
                            clave_asignatura: asignatura,
                            grado: grado,
                            grupo: grupo
                        })
                    });
                    
                    const result = await response.json();
                    
                    if (result.exists) {
                        conflictAlert.innerHTML = '<i class="fas fa-exclamation-triangle"></i><span>' + 
                                                result.message + '</span>';
                        conflictAlert.className = 'conflict-alert warning';
                        currentAssignmentId = result.id_asignacion || null;
                        isDuplicateMaster = true;
                        return true;
                    } else {
                        conflictAlert.innerHTML = '<i class="fas fa-check-circle"></i><span>No se detectaron duplicados en el maestro</span>';
                        conflictAlert.className = 'conflict-alert';
                        currentAssignmentId = null;
                        isDuplicateMaster = false;
                        return false;
                    }
                    
                } catch (error) {
                    console.error('Error al verificar duplicado:', error);
                    return false;
                }
            }
            
            async function insertMaster() {
                const ciclo_escolar = document.getElementById('ciclo_escolar').value;
                const plan_estudio = document.getElementById('plan_estudio').value;
                const docente = document.getElementById('docente').value;
                const asignatura = document.getElementById('asignatura').value;
                const grado = document.getElementById('grado').value;
                const grupo = document.getElementById('grupo').value;
                
                try {
                    const response = await fetch('../../controllers/HorariosController.php?action=insert_master', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: new URLSearchParams({
                            id_ciclo_escolar: ciclo_escolar,
                            id_plan_estudio: plan_estudio,
                            clave_docente: docente,
                            clave_asignatura: asignatura,
                            grado: grado,
                            grupo: grupo
                        })
                    });
                    
                    const result = await response.json();
                    return result;
                    
                } catch (error) {
                    console.error('Error al insertar maestro:', error);
                    return { success: false, message: 'Error al insertar maestro' };
                }
            }
            
            async function insertDetail(id_asignacion) {
                const dia = document.getElementById('dia').value;
                const horario = document.getElementById('horario').value;
                
                try {
                    const response = await fetch('../../controllers/HorariosController.php?action=insert_detail', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: new URLSearchParams({
                            id_asignacion: id_asignacion,
                            id_hora: horario,
                            dia_semana: dia
                        })
                    });
                    
                    const result = await response.json();
                    return result;
                    
                } catch (error) {
                    console.error('Error al insertar detalle:', error);
                    return { success: false, message: 'Error al insertar horario' };
                }
            }
            
            form.addEventListener('submit', async function(e) {
                e.preventDefault();
                
                const submitBtn = form.querySelector('.btn-submit');
                const originalText = submitBtn.innerHTML;
                
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Validando campos...';
                submitBtn.disabled = true;
                
                const masterErrors = validateMasterRequiredFields();
                if (masterErrors.length > 0) {
                    conflictAlert.innerHTML = `<i class="fas fa-exclamation-circle"></i><span> ${masterErrors[0]}</span>`;
                    conflictAlert.className = 'conflict-alert error';
                    conflictAlert.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                    return;
                }
                
                const detailErrors = validateDetailRequiredFields();
                if (detailErrors.length > 0) {
                    conflictAlert.innerHTML = `<i class="fas fa-exclamation-circle"></i><span> ${detailErrors[0]}</span>`;
                    conflictAlert.className = 'conflict-alert error';
                    conflictAlert.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                    return;
                }
                
                conflictAlert.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Verificando duplicados...</span>';
                conflictAlert.className = 'conflict-alert warning';
                
                const hasDuplicate = await checkDuplicateMaster();
                
                let id_asignacion_a_usar = null;
                
                if (hasDuplicate && currentAssignmentId) {
                    id_asignacion_a_usar = currentAssignmentId;
                    conflictAlert.innerHTML = '<i class="fas fa-info-circle"></i><span>Usando asignación existente...</span>';
                } else {
                    conflictAlert.innerHTML = '<i class="fas fa-spinner fa-spin"></i><span>Creando nueva asignación...</span>';
                    
                    const masterResult = await insertMaster();
                    
                    if (!masterResult.success) {
                        conflictAlert.innerHTML = `<i class="fas fa-times-circle"></i><span> ${masterResult.message}</span>`;
                        conflictAlert.className = 'conflict-alert error';
                        submitBtn.innerHTML = originalText;
                        submitBtn.disabled = false;
                        return;
                    }
                    
                    id_asignacion_a_usar = masterResult.id_asignacion;
                }
                
                submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Asignando horario...';
                
                const detailResult = await insertDetail(id_asignacion_a_usar);
                
                if (detailResult.success) {
                    if (detailResult.mode === 'deleted') {
                        conflictAlert.innerHTML = '<i class="fas fa-check-circle"></i><span>Horario eliminado (toggle off)</span>';
                        conflictAlert.className = 'conflict-alert';
                        
                        setTimeout(() => {
                            alert('Horario eliminado correctamente.\n\nRedirigiendo a la lista de horarios...');
                            window.location.href = '../../controllers/HorariosController.php';
                        }, 1500);
                    } else {
                        conflictAlert.innerHTML = '<i class="fas fa-check-circle"></i><span>Horario asignado exitosamente</span>';
                        conflictAlert.className = 'conflict-alert';
                        
                        if (!hasDuplicate) {
                            form.reset();
                            inputs.forEach(input => {
                                input.classList.remove('valid');
                                input.style.borderColor = '';
                                input.style.boxShadow = '';
                            });
                        }
                        
                        setTimeout(() => {
                            alert('Horario asignado correctamente.\n\nRedirigiendo a la lista de horarios...');
                            window.location.href = '../../controllers/HorariosController.php';
                        }, 1500);
                    }
                } else {
                    conflictAlert.innerHTML = `<i class="fas fa-times-circle"></i><span> ${detailResult.message}</span>`;
                    conflictAlert.className = 'conflict-alert error';
                    submitBtn.innerHTML = originalText;
                    submitBtn.disabled = false;
                    
                    if (detailResult.message.includes('Parámetros incompletos') || 
                        detailResult.message.includes('Maestro no encontrado')) {
                        conflictAlert.scrollIntoView({ behavior: 'smooth', block: 'center' });
                    }
                }
            });
            
            checkDuplicateMaster();
        });