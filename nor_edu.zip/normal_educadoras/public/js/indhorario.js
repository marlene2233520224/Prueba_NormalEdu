        // Sistema de vistas
        document.querySelectorAll('.vista-tab').forEach(tab => {
            tab.addEventListener('click', function() {
                document.querySelectorAll('.vista-tab').forEach(t => t.classList.remove('activa'));
                document.querySelectorAll('.vista-contenido').forEach(c => c.classList.remove('activa'));
                this.classList.add('activa');
                document.getElementById(`vista-${this.getAttribute('data-vista')}`).classList.add('activa');
            });
        });

        // Selector de grupos
        document.querySelectorAll('.grupo-card').forEach(card => {
            card.addEventListener('click', function() {
                document.querySelectorAll('.grupo-card').forEach(c => c.classList.remove('activo'));
                this.classList.add('activo');
                document.querySelectorAll('.tabla-horario-container').forEach(t => t.classList.add('hidden'));
                const grado = this.getAttribute('data-grado'), grupo = this.getAttribute('data-grupo');
                document.querySelector(`.tabla-horario-container[data-grupo="${grado}-${grupo}"]`)?.classList.remove('hidden');
            });
        });

        // Funciones básicas
        function resetFilters() {
            ['filtro-grado', 'filtro-grupo', 'filtro-docente'].forEach(id => document.getElementById(id).value = '');
            showNotification('Filtros limpiados', 'info');
        }

        function agregarEnCelda(dia, horaId) {
            window.location.href = `../views/horarios/asignar.php?dia=${encodeURIComponent(dia)}&horaId=${horaId}`;
        }

        function verDetalleAsignacion(id) {
            alert(`Mostrando detalles de la asignación #${id}`);
        }

        function showNotification(mensaje, tipo = 'info') {
            const notificacion = document.createElement('div');
            notificacion.style.cssText = `position: fixed; top: 20px; right: 20px; padding: 15px 20px; background: ${tipo === 'success' ? '#10b981' : tipo === 'error' ? '#dc2626' : '#3b82f6'}; color: white; border-radius: 8px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 1000; display: flex; align-items: center; gap: 10px; animation: slideIn 0.3s ease;`;
            notificacion.innerHTML = `<i class="fas fa-${tipo === 'success' ? 'check-circle' : tipo === 'error' ? 'exclamation-circle' : 'info-circle'}"></i><span>${mensaje}</span>`;
            document.body.appendChild(notificacion);
            setTimeout(() => { notificacion.style.animation = 'slideOut 0.3s ease'; setTimeout(() => notificacion.remove(), 300); }, 3000);
        }

        // Búsqueda
        const searchInput = document.querySelector('input[placeholder="Buscar asignación..."]');
        if (searchInput) {
            searchInput.addEventListener('input', function() {
                const term = this.value.toLowerCase();
                if (term.length > 2) {
                    document.querySelectorAll('.asignacion-materia, .docente-nombre').forEach(el => {
                        const contenedor = el.closest('.asignacion, .docente-item');
                        if (contenedor) contenedor.style.display = el.textContent.toLowerCase().includes(term) ? '' : 'none';
                    });
                } else {
                    document.querySelectorAll('.asignacion, .docente-item').forEach(el => el.style.display = '');
                }
            });
        }

        // Inicializar
        document.querySelector('.grupo-card')?.click();
        
        // Animaciones CSS
        const style = document.createElement('style');
        style.textContent = `@keyframes slideIn {from { transform: translateX(100%); opacity: 0; } to { transform: translateX(0); opacity: 1; }} @keyframes slideOut {from { transform: translateX(0); opacity: 1; } to { transform: translateX(100%); opacity: 0; }}`;
        document.head.appendChild(style);