document.addEventListener('DOMContentLoaded', function() {
    const imagePath = 'public/images/estef.png';
    
    console.log('Cargando imagen desde:', imagePath);
    
    const bgImage = new Image();
    bgImage.src = imagePath;
    
    function adjustBackground() {
        const body = document.body;
        const width = window.innerWidth;
        const height = window.innerHeight;
        const orientation = width > height ? 'landscape' : 'portrait';
        
        if (width < 768 && orientation === 'portrait') {
            body.style.backgroundSize = 'auto 100%';
            body.style.backgroundPosition = 'top center';
        } else if (width < 768 && orientation === 'landscape') {
            body.style.backgroundSize = '100% auto';
            body.style.backgroundPosition = 'center center';
        } else if (width > 1920) {
            body.style.backgroundSize = '100% 100%';
        } else {
            body.style.backgroundSize = 'cover';
        }
        
        console.log(`Ajustando fondo: ${width}x${height} (${orientation})`);
    }
    
    adjustBackground();
    window.addEventListener('resize', adjustBackground);
    window.addEventListener('orientationchange', adjustBackground);
    
    bgImage.onerror = function() {
        console.log('Imagen no encontrada en:', imagePath);
        console.log('Usando degradado alternativo');
        document.body.style.background = 'linear-gradient(135deg, #C62828, #37474F)';
    };
    
    bgImage.onload = function() {
        console.log('Imagen cargada correctamente desde:', imagePath);
    };
});