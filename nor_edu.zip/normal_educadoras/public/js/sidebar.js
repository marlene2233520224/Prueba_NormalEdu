document.addEventListener('DOMContentLoaded', function() {
        const navItems = document.querySelectorAll('.nav-item');
        const currentPage = window.location.pathname.split('/').pop();
        
        // Set active page
        navItems.forEach(item => {
            const link = item.querySelector('.nav-link');
            if (link.href.includes(currentPage) && !link.classList.contains('logout-link')) {
                item.classList.add('active');
            }
            
            // Click effect
            link.addEventListener('click', function(e) {
                if (!this.classList.contains('logout-link')) {
                    navItems.forEach(i => i.classList.remove('active'));
                    item.classList.add('active');
                }
            });
        });
    });