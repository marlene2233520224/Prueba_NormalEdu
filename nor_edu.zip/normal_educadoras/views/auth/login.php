<?php
$base_path = '';

$script_path = $_SERVER['SCRIPT_NAME'];

if (strpos($script_path, 'views/auth/login.php') !== false) {
    $base_path = '../../';
}
elseif (strpos($script_path, 'index.php') !== false) {
    $base_path = '';
}
elseif (strpos($script_path, 'controllers/AuthController.php') !== false) {
    $base_path = '../';
}

if (!isset($error)) {
    $error = null;
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Iniciar Sesión - Normal de Educadoras</title>    
    <link rel="stylesheet" href="<?= $base_path ?>public/css/style.css">
    <link rel="stylesheet" href="<?= $base_path ?>public/css/login.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <div class="login-container">
        <div class="login-header">
            <div class="logo-container">
                <div class="logo-icon">
                    <i class="fas fa-graduation-cap"></i>
                </div>
                <div class="logo-text">
                    <h1>Normal de Educadoras</h1>
                    <p>Formación de Excelencia</p>
                </div>
            </div>
        </div>
        
        <div class="login-content">
            <h2>Acceso al Sistema</h2>

            <?php if (isset($error)): ?>
                <div class="error"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form method="POST" action="<?= $base_path ?>controllers/AuthController.php">
                <div class="form-group">
                    <label for="usuario">Usuario</label>
                    <div class="input-wrapper">
                        <i class="fas fa-user"></i>
                        <input type="text" id="usuario" name="usuario" placeholder="Ingrese su usuario" required autofocus>
                    </div>
                </div>
                <div class="form-group">
                    <label for="contrasena">Contraseña</label>
                    <div class="input-wrapper">
                        <i class="fas fa-lock"></i>
                        <input type="password" id="contrasena" name="contrasena" placeholder="Ingrese su contraseña" required>
                    </div>
                </div>
                
                <button type="submit" class="btn-login">
                    <i class="fas fa-sign-in-alt"></i>
                    Iniciar Sesión
                </button>
            </form>
        </div>
    </div>

    <script src="<?= $base_path ?>public/js/login.js"></script>
</body>
</html>