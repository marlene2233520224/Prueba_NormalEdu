<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Normal de Educadoras</title>
    <link rel="stylesheet" href="../public/css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>
<body>
    <?php include '../views/layout/sidebar.php'; ?>

    <div class="main-content">
            <?php include '../views/layout/header.php'; ?>
        <div class="dashboard-header">
            <h1 style="font-family: 'Segoe UI', system-ui, sans-serif; font-size: 2.4rem; font-weight: 700; color: #111827; margin: 2rem 0; padding-left: 15px; border-left: 3px solid #dc2626; background: linear-gradient(90deg, rgba(220, 38, 38, 0.05), transparent);">
            Panel de Control</h1>
        </div>

        <div class="card-grid">
            <div class="card" onclick="window.location.href='../views/horarios/asignar.php'">
                <i class="fas fa-calendar-check" style="color: #923838ff;"></i>
                <div class="icon-subtext"></div>
                <h3>Asignar sin conflictos</h3>
            </div>

            <div class="card" onclick="window.location.href='../controllers/ReportesController.php'">
                <i class="fas fa-users" style="color: #923838ff;"></i>
                <div class="icon-subtext"></div>
                <h3>Vista por docente o grupo</h3>
            </div>

            <div class="card" onclick="window.location.href='../controllers/HorariosController.php'">
                <i class="fas fa-calendar-alt" style="color: #923838ff;"></i>
                <div class="icon-subtext"></div>
                <h3>Ver horario</h3>
            </div>
        </div>

        <?php include '../views/layout/footer.php'; ?>
    </div>
</body>
</html>