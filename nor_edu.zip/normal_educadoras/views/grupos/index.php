<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grupos - Normal de Educadoras</title>
    <link rel="stylesheet" href="../public/css/style.css">
    <style>
        .grupos-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .actions {
            display: flex;
            gap: 10px;
        }

        .table th,
        .table td {
            text-align: left;
            padding: 12px 15px;
        }

        .table th {
            background-color: var(--color-gris);
            color: white;
        }

        .table tr:nth-child(even) {
            background-color: var(--color-gris-claro);
        }

        .table tr:hover {
            background-color: #e0e0e0;
        }

        .status-active {
            color: var(--color-verde-exito);
            font-weight: 600;
        }

        .status-inactive {
            color: var(--color-rojo-error);
            font-weight: 600;
        }
    </style>
</head>
<body>
    <?php include '../views/layout/sidebar.php'; ?>

    <div class="main-content">
        <?php include '../views/layout/header.php'; ?>
        <div class="grupos-header">
            <h1 style="font-family: 'Segoe UI', system-ui, sans-serif; font-size: 2.4rem; font-weight: 700; color: #111827; margin: 2rem 0; padding-left: 15px; border-left: 3px solid #dc2626; background: linear-gradient(90deg, rgba(220, 38, 38, 0.05), transparent);">
            Lista de Grupos</h1>
      <div class="actions">
                <a href="#" class="btn btn-primary">+ Nuevo Grupo</a>
                <input type="text" placeholder="Buscar grupo..." style="padding: 8px; border: 1px solid #ddd; border-radius: 5px;">
            </div>
        </div>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Clave</th>
                    <th>Descripción</th>
                    <th>Grado</th>
                    <th>Turno</th>
                    <th>Estado</th>
                    <th>Acciones</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td>1</td>
                    <td>101</td>
                    <td>1° A</td>
                    <td>1er Grado</td>
                    <td>Matutino</td>
                    <td><span class="status-active">Activo</span></td>
                    <td>
                        <a href="#" class="btn btn-secondary">Editar</a>
                        <a href="#" class="btn btn-danger">Eliminar</a>
                    </td>
                </tr>
                <tr>
                    <td>2</td>
                    <td>102</td>
                    <td>1° B</td>
                    <td>1er Grado</td>
                    <td>Vespertino</td>
                    <td><span class="status-active">Activo</span></td>
                    <td>
                        <a href="#" class="btn btn-secondary">Editar</a>
                        <a href="#" class="btn btn-danger">Eliminar</a>
                    </td>
                </tr>
                <tr>
                    <td>3</td>
                    <td>201</td>
                    <td>2° A</td>
                    <td>2do Grado</td>
                    <td>Matutino</td>
                    <td><span class="status-active">Activo</span></td>
                    <td>
                        <a href="#" class="btn btn-secondary">Editar</a>
                        <a href="#" class="btn btn-danger">Eliminar</a>
                    </td>
                </tr>
            </tbody>
        </table>

        <?php include '../views/layout/footer.php'; ?>
    </div>
</body>
</html>