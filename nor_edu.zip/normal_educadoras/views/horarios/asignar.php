<?php
require_once '../../config/database.php';

$database = new Database();
$conn = $database->getConnection();

try {
    $sql_ciclos = "SELECT id_ciclo_escolar, txt_ciclo_escolar 
                   FROM cat_ciclo_escolar 
                   WHERE id_status = 1 
                   ORDER BY txt_ciclo_escolar ASC";
    $stmt_ciclos = $conn->prepare($sql_ciclos);
    $stmt_ciclos->execute();
    $ciclos = $stmt_ciclos->fetchAll(PDO::FETCH_ASSOC);

    $sql_planes = "SELECT id_plan, txt_plan
                   FROM cat_plan_estudio 
                   WHERE id_status = 1 
                   ORDER BY id_plan, txt_plan DESC";
    $stmt_planes = $conn->prepare($sql_planes); 
    $stmt_planes->execute();
    $planes = $stmt_planes->fetchAll(PDO::FETCH_ASSOC);

    $sql_docentes = "SELECT clave_docente, txt_paterno, txt_materno, txt_nombre 
                     FROM cat_docente 
                     WHERE id_status = 1 
                     AND clave_docente != '' 
                     ORDER BY txt_paterno, txt_materno, txt_nombre";
    $stmt_docentes = $conn->prepare($sql_docentes);
    $stmt_docentes->execute();
    $docentes = $stmt_docentes->fetchAll(PDO::FETCH_ASSOC);

    $sql_asignaturas = "SELECT clave_asignatura, txt_asignatura 
                        FROM cat_asignaturas 
                        WHERE id_status = 1 
                        ORDER BY txt_asignatura";
    $stmt_asignaturas = $conn->prepare($sql_asignaturas);
    $stmt_asignaturas->execute();
    $asignaturas = $stmt_asignaturas->fetchAll(PDO::FETCH_ASSOC);

    $sql_grados = "SELECT grado FROM grado ORDER BY grado";
    $stmt_grados = $conn->prepare($sql_grados);
    $stmt_grados->execute();
    $grados = $stmt_grados->fetchAll(PDO::FETCH_ASSOC);

    $sql_grupos = "SELECT grupo FROM grupo ORDER BY grupo";
    $stmt_grupos = $conn->prepare($sql_grupos);
    $stmt_grupos->execute();
    $grupos = $stmt_grupos->fetchAll(PDO::FETCH_ASSOC);

    $sql_horas = "SELECT idnum, horas FROM horas ORDER BY idnum";
    $stmt_horas = $conn->prepare($sql_horas);
    $stmt_horas->execute();
    $horas = $stmt_horas->fetchAll(PDO::FETCH_ASSOC);

} catch(PDOException $e) {
    error_log("Error al obtener datos de la base de datos: " . $e->getMessage());
    $ciclos = [];
    $planes = [];
    $docentes = [];
    $asignaturas = [];
    $grados = [];
    $grupos = [];
    $horas = [];
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Asignar Horario - Normal de Educadoras</title>
    <link rel="stylesheet" href="../../public/css/asignar.css">
</head>
<body>

    <div class="form-container">
        <div class="form-header">
            <h1 class="form-title">
                <i class="fas fa-calendar-plus"></i>
                Asignar Horario
            </h1>
            <p class="form-subtitle">Complete los detalles para asignar un nuevo horario académico</p>
        </div>

        <div class="form-content">
            <form id="asignarForm">
                <div class="form-grid">
                    <div class="form-group">
                        <label for="ciclo_escolar">Ciclo Escolar</label>
                        <div class="select-wrapper">
                            <select class="form-control" id="ciclo_escolar" name="ciclo_escolar" required>
                                <option value="">Selecciona un ciclo escolar</option>
                                <?php foreach ($ciclos as $ciclo): ?>
                                    <?php 
                                    $id_ciclo = htmlspecialchars($ciclo['id_ciclo_escolar']);
                                    $txt_ciclo = htmlspecialchars($ciclo['txt_ciclo_escolar']);
                                    ?>
                                    <option value="<?php echo $id_ciclo; ?>"><?php echo $txt_ciclo; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <i class="fas fa-check valid-icon"></i>
                    </div>

                    <div class="form-group">
                        <label for="plan_estudio">Plan de Estudio</label>
                        <div class="select-wrapper">
                            <select class="form-control" id="plan_estudio" name="plan_estudio" required>
                                <option value="">Selecciona un plan de estudio</option>
                                <?php foreach ($planes as $plan): ?>
                                    <?php 
                                    $id_plan = htmlspecialchars($plan['id_plan']);
                                    $txt_plan = htmlspecialchars($plan['txt_plan']);
                                    ?>
                                    <option value="<?php echo $id_plan; ?>"><?php echo $txt_plan; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <i class="fas fa-check valid-icon"></i>
                    </div>

                    <div class="form-group">
                        <label for="docente">Docente</label>
                        <div class="select-wrapper">
                            <select class="form-control" id="docente" name="docente" required>
                                <option value="">Selecciona un docente</option>
                                <?php foreach ($docentes as $docente): ?>
                                    <?php 
                                    $nombre_completo = trim($docente['txt_paterno'] . " " . $docente['txt_materno'] . " " . $docente['txt_nombre']);
                                    $clave = htmlspecialchars($docente['clave_docente']);
                                    $nombre = htmlspecialchars($nombre_completo);
                                    ?>
                                    <option value="<?php echo $clave; ?>"><?php echo $nombre; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <i class="fas fa-check valid-icon"></i>
                    </div>

                    <div class="form-group">
                        <label for="asignatura">Asignatura</label>
                        <div class="select-wrapper">
                            <select class="form-control" id="asignatura" name="clave_asignatura" required>
                                <option value="">Selecciona una asignatura</option>
                                <?php foreach ($asignaturas as $asignatura): ?>
                                    <?php 
                                    $clave = htmlspecialchars($asignatura['clave_asignatura']);
                                    $nombre = htmlspecialchars($asignatura['txt_asignatura']);
                                    ?>
                                    <option value="<?php echo $clave; ?>"><?php echo $nombre; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <i class="fas fa-check valid-icon"></i>
                    </div>

                    <div class="form-group">
                        <label for="grado">Grado</label>
                        <div class="select-wrapper">
                            <select class="form-control" id="grado" name="grado" required>
                                <option value="">Selecciona un grado</option>
                                <?php foreach ($grados as $grado_item): ?>
                                    <?php 
                                    $grado_valor = htmlspecialchars($grado_item['grado']);
                                    $grado_texto = $grado_valor . "°";
                                    ?>
                                    <option value="<?php echo $grado_valor; ?>"><?php echo $grado_texto; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <i class="fas fa-check valid-icon"></i>
                    </div>

                    <div class="form-group">
                        <label for="grupo">Grupo</label>
                        <div class="select-wrapper">
                            <select class="form-control" id="grupo" name="grupo" required>
                                <option value="">Selecciona un grupo</option>
                                <?php foreach ($grupos as $grupo_item): ?>
                                    <?php 
                                    $grupo_valor = htmlspecialchars($grupo_item['grupo']);
                                    ?>
                                    <option value="<?php echo $grupo_valor; ?>"><?php echo $grupo_valor; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <i class="fas fa-check valid-icon"></i>
                    </div>

                    <div class="time-group">
                        <h3><i class="fas fa-clock"></i> Horario</h3>
                        <div class="time-row">
                            <div class="form-group">
                                <label for="dia">Día</label>
                                <div class="select-wrapper">
                                    <select class="form-control" id="dia" name="dia" required>
                                        <option value="">Selecciona un día</option>
                                        <option value="lunes">Lunes</option>
                                        <option value="martes">Martes</option>
                                        <option value="miercoles">Miércoles</option>
                                        <option value="jueves">Jueves</option>
                                        <option value="viernes">Viernes</option>
                                    </select>
                                </div>
                                <i class="fas fa-check valid-icon"></i>
                            </div>

                            <div class="form-group">
                                <label for="horario">Horario (Inicio - Fin)</label>
                                <div class="select-wrapper">
                                    <select class="form-control" id="horario" name="horario" required>
                                        <option value="">Selecciona un horario</option>
                                        <?php foreach ($horas as $hora): ?>
                                            <?php 
                                            $id_hora = htmlspecialchars($hora['idnum']);
                                            $horario_texto = htmlspecialchars($hora['horas']);
                                            ?>
                                            <option value="<?php echo $id_hora; ?>"><?php echo $horario_texto; ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </div>
                                <i class="fas fa-check valid-icon"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="conflict-alert" id="conflictAlert">
                    <i class="fas fa-check-circle"></i>
                    <span>No se detectaron conflictos en el horario</span>
                </div>

                <div class="form-actions">
                    <button type="submit" class="btn btn-submit">
                        <i class="fas fa-calendar-check"></i>
                        Asignar Horario
                    </button>
                    <a href="../../controllers/HorariosController.php" class="btn btn-cancel">
                        <i class="fas fa-times"></i>
                        Cancelar
                    </a>
                </div>
            </form>
        </div>
    </div>
    <script src="../../public/js/asignar.js"></script>                                           
</body>
</html>