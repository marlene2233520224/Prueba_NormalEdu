<?php
require_once __DIR__ . '/../../config/database.php'; 

$database = new Database();
$conn = $database->getConnection();

// Datos iniciales
$dias = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes'];
$ciclo_actual = 36;

// Obtener datos básicos
try {
    $horas = $conn->query("SELECT idnum, horas FROM horas ORDER BY idnum")->fetchAll(PDO::FETCH_ASSOC);
    $grados = $conn->query("SELECT grado FROM grado ORDER BY grado")->fetchAll(PDO::FETCH_ASSOC);
    $grupos = $conn->query("SELECT grupo FROM grupo ORDER BY grupo")->fetchAll(PDO::FETCH_ASSOC);
    $docentes = $conn->query("SELECT clave_docente, CONCAT(txt_paterno, ' ', txt_materno, ' ', txt_nombre) AS nombre_completo FROM cat_docente WHERE id_status = 1 ORDER BY txt_paterno")->fetchAll(PDO::FETCH_ASSOC);
    
    // Obtener asignaciones
    $sql = "SELECT ca.id_asignacion, ca.grado, ca.grupo, ca.clave_docente, ca.clave_asignatura,
                   cad.dia_semana, cad.id_hora, h.horas as horario,
                   cd.nombre_completo, ca2.txt_asignatura, cp.txt_plan
            FROM ctrl_asignacion ca
            JOIN ctrl_asignacion_detalle2 cad ON ca.id_asignacion = cad.id_asignacion
            JOIN horas h ON cad.id_hora = h.idnum
            LEFT JOIN (SELECT clave_docente, CONCAT(txt_paterno, ' ', txt_materno, ' ', txt_nombre) as nombre_completo FROM cat_docente) cd ON ca.clave_docente = cd.clave_docente
            JOIN cat_asignaturas ca2 ON ca.clave_asignatura = ca2.clave_asignatura
            JOIN cat_plan_estudio cp ON ca.id_plan_estudio = cp.id_plan
            WHERE ca.id_ciclo_escolar = ? AND cad.id_status = 1
            ORDER BY ca.grado, ca.grupo, cad.id_hora";
    
    $stmt = $conn->prepare($sql);
    $stmt->execute([$ciclo_actual]);
    $asignaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Estadísticas
    $total_asignaciones = count($asignaciones);
    $total_espacios = count($horas) * 5;
    $porcentaje_ocupado = $total_espacios > 0 ? round(($total_asignaciones / $total_espacios) * 100) : 0;
    
} catch(PDOException $e) {
    error_log("Error BD: " . $e->getMessage());
    $horas = $grados = $grupos = $docentes = $asignaciones = [];
    $total_asignaciones = $total_espacios = $porcentaje_ocupado = 0;
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Horarios - Normal de Educadoras</title>
    <link rel="stylesheet" href="../public/css/style.css">
    <link rel="stylesheet" href="../public/css/indhorario.css">
</head>
<body>
    <?php include '../views/layout/sidebar.php'; ?>

    <div class="main-content">
            <?php include '../views/layout/header.php'; ?>
        <div class="horarios-header">
            <h1 style="font-family: 'Segoe UI', system-ui, sans-serif; font-size: 2.4rem; font-weight: 700; color: #111827; margin: 2rem 0; padding-left: 15px; border-left: 3px solid #dc2626; background: linear-gradient(90deg, rgba(220, 38, 38, 0.05), transparent);">
                Horarios - Normal de Educadoras
            </h1>
            <div class="actions">
                <a href="../views/horarios/asignar.php" class="btn btn-primary"><i class="fas fa-plus"></i> Nuevo Horario</a>
                <input type="text" placeholder="Buscar asignación..." style="padding: 10px 15px; border: 2px solid #e5e7eb; border-radius: 8px; min-width: 250px;">
            </div>
        </div>

        <!-- Estadísticas -->
        <div class="estadisticas-grid">
            <div class="estadistica-card espacios"><div class="estadistica-titulo">Espacios totales</div><div class="estadistica-valor"><?= $total_espacios ?></div><div class="estadistica-desc">Horas × Días</div></div>
            <div class="estadistica-card horas"><div class="estadistica-titulo">Horas diarias</div><div class="estadistica-valor"><?= count($horas) ?></div><div class="estadistica-desc">De 7:00 a 20:00</div></div>
            <div class="estadistica-card dias"><div class="estadistica-titulo">Asignaciones activas</div><div class="estadistica-valor"><?= $total_asignaciones ?></div><div class="estadistica-desc">En este ciclo</div></div>
            <div class="estadistica-card ocupacion"><div class="estadistica-titulo">Ocupación</div><div class="estadistica-valor"><?= $porcentaje_ocupado ?>%</div><div class="estadistica-desc"><?= $total_asignaciones ?>/<?= $total_espacios ?> espacios</div></div>
        </div>

        <!-- Filtros -->
        <div class="filters">
            <select id="filtro-grado"><option value="">Todos los grados</option><?php foreach ($grados as $g): ?><option value="<?= htmlspecialchars($g['grado']) ?>"><?= htmlspecialchars($g['grado']) ?>° Grado</option><?php endforeach; ?></select>
            <select id="filtro-grupo"><option value="">Todos los grupos</option><?php foreach ($grupos as $g): ?><option value="<?= htmlspecialchars($g['grupo']) ?>">Grupo <?= htmlspecialchars($g['grupo']) ?></option><?php endforeach; ?></select>
            <select id="filtro-docente"><option value="">Todos los docentes</option><?php foreach ($docentes as $d): ?><option value="<?= htmlspecialchars($d['clave_docente']) ?>"><?= htmlspecialchars($d['nombre_completo']) ?></option><?php endforeach; ?></select>
            <button onclick="resetFilters()" style="padding: 10px 20px; background: #6b7280; color: white; border: none; border-radius: 8px; cursor: pointer; font-weight: 600;"><i class="fas fa-times"></i> Limpiar</button>
        </div>

        <!-- Sistema de Vistas -->
        <div class="vistas-container">
            <div class="vistas-header">
                <button class="vista-tab activa" data-vista="grupo"><i class="fas fa-users"></i> Por Grupo</button>
                <button class="vista-tab" data-vista="docente"><i class="fas fa-chalkboard-teacher"></i> Por Docente</button>
                <button class="vista-tab" data-vista="matriz"><i class="fas fa-calendar-alt"></i> Vista Matriz</button>
            </div>

            <!-- Vista por Grupo -->
            <div class="vista-contenido activa" id="vista-grupo">
                <?php if (empty($asignaciones)): ?>
                    <div class="mensaje-vacio"><i class="fas fa-calendar-plus"></i><h3>No hay horarios asignados</h3><p>Comienza creando tu primer horario para este ciclo escolar.</p><a href="../views/horarios/asignar.php" class="btn btn-primary" style="margin-top: 15px;"><i class="fas fa-plus"></i> Crear primer horario</a></div>
                <?php else: ?>
                    <?php 
                    $combinaciones = [];
                    foreach ($asignaciones as $a) {
                        $key = $a['grado'] . '-' . $a['grupo'];
                        if (!in_array($key, $combinaciones)) $combinaciones[] = $key;
                    }
                    sort($combinaciones);
                    ?>
                    
                    <div class="grupo-selector">
                        <?php foreach ($combinaciones as $i => $combinacion): list($g, $gr) = explode('-', $combinacion); ?>
                            <div class="grupo-card <?= $i === 0 ? 'activo' : '' ?>" data-grado="<?= $g ?>" data-grupo="<?= $gr ?>"><?= $g ?>° - Grupo <?= $gr ?></div>
                        <?php endforeach; ?>
                    </div>

                    <?php foreach ($combinaciones as $i => $combinacion): list($grado_actual, $grupo_actual) = explode('-', $combinacion); ?>
                        <?php 
                        $horario_grupo = array_filter($asignaciones, fn($a) => $a['grado'] == $grado_actual && $a['grupo'] == $grupo_actual);
                        $horario_organizado = [];
                        foreach ($horario_grupo as $a) $horario_organizado[$a['dia_semana']][$a['id_hora']] = $a;
                        ?>
                        
                        <div class="tabla-horario-container <?= $i === 0 ? '' : 'hidden' ?>" data-grupo="<?= $grado_actual . '-' . $grupo_actual ?>">
                            <h3 style="margin: 20px 0; color: #374151;"><i class="fas fa-graduation-cap"></i> Horario <?= $grado_actual ?>° Grado - Grupo <?= $grupo_actual ?> <small style="color: #6b7280; font-size: 14px; margin-left: 10px;"><?= count($horario_grupo) ?> asignaciones</small></h3>
                            
                            <table class="tabla-horario-grupo">
                                <thead><tr><th class="hora-fija">Hora</th><?php foreach ($dias as $dia): ?><th><?= $dia ?></th><?php endforeach; ?></tr></thead>
                                <tbody>
                                    <?php foreach ($horas as $hora): ?>
                                        <tr><td class="hora-fija"><?= htmlspecialchars($hora['horas']) ?></td>
                                            <?php foreach ($dias as $dia): ?>
                                                <td>
                                                    <?php if (isset($horario_organizado[$dia][$hora['idnum']])): $a = $horario_organizado[$dia][$hora['idnum']]; ?>
                                                        <div class="asignacion" onclick="verDetalleAsignacion(<?= $a['id_asignacion'] ?>)" title="Click para ver detalles">
                                                            <div class="asignacion-materia"><?= htmlspecialchars($a['txt_asignatura']) ?><span class="badge-plan"><?= htmlspecialchars($a['txt_plan']) ?></span></div>
                                                            <div class="asignacion-docente"><i class="fas fa-user"></i> <?= htmlspecialchars($a['nombre_completo']) ?></div>
                                                            <div class="asignacion-info"><span><?= htmlspecialchars($a['horario']) ?></span><span>G<?= $a['grado'] ?><?= $a['grupo'] ?></span></div>
                                                        </div>
                                                    <?php endif; ?>
                                                </td>
                                            <?php endforeach; ?>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Vista por Docente -->
            <div class="vista-contenido" id="vista-docente">
                <?php 
                $asignaciones_por_docente = [];
                foreach ($asignaciones as $a) {
                    $clave = $a['clave_docente'];
                    if (!isset($asignaciones_por_docente[$clave])) {
                        $asignaciones_por_docente[$clave] = ['nombre' => $a['nombre_completo'] ?? 'Docente ' . $clave, 'asignaciones' => []];
                    }
                    $asignaciones_por_docente[$clave]['asignaciones'][] = $a;
                }
                ?>
                
                <?php if (empty($asignaciones_por_docente)): ?>
                    <div class="mensaje-vacio"><i class="fas fa-users-slash"></i><h3>No hay docentes con horarios asignados</h3><p>Comienza asignando horarios a los docentes.</p></div>
                <?php else: ?>
                    <?php foreach ($asignaciones_por_docente as $clave => $docente): ?>
                        <div class="docente-item">
                            <div class="docente-header"><div class="docente-nombre"><i class="fas fa-user-tie"></i> <?= htmlspecialchars($docente['nombre']) ?></div><div class="docente-clave">Clave: <?= htmlspecialchars($clave) ?></div></div>
                            <div class="docente-horarios">
                                <?php foreach ($docente['asignaciones'] as $a): ?>
                                    <div class="horario-item">
                                        <div class="horario-dia"><i class="far fa-calendar-alt"></i> <?= htmlspecialchars($a['dia_semana']) ?></div>
                                        <div class="horario-hora"><i class="far fa-clock"></i> <?= htmlspecialchars($a['horario']) ?></div>
                                        <div class="horario-details">
                                            <div><strong><?= htmlspecialchars($a['txt_asignatura']) ?></strong></div>
                                            <div><?= $a['grado'] ?>° Grado - Grupo <?= $a['grupo'] ?></div>
                                            <div>Plan: <?= htmlspecialchars($a['txt_plan']) ?></div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>

            <!-- Vista Matriz -->
            <div class="vista-contenido" id="vista-matriz">
                <?php 
                $matriz = [];
                foreach ($asignaciones as $a) $matriz[$a['id_hora']][$a['dia_semana']][] = $a;
                ?>
                
                <div class="calendar" id="calendarioHorarios">
                    <div class="calendar-time">Hora</div><?php foreach ($dias as $dia): ?><div class="calendar-header"><?= $dia ?></div><?php endforeach; ?>
                    <?php foreach ($horas as $hora): ?>
                        <div class="calendar-time" data-hora-id="<?= htmlspecialchars($hora['idnum']) ?>"><?= htmlspecialchars($hora['horas']) ?></div>
                        <?php foreach ($dias as $dia): ?>
                            <div class="calendar-cell" data-dia="<?= $dia ?>" data-hora-id="<?= $hora['idnum'] ?>" data-hora-texto="<?= htmlspecialchars($hora['horas']) ?>" onclick="agregarEnCelda('<?= $dia ?>', <?= $hora['idnum'] ?>)">
                                <?php if (isset($matriz[$hora['idnum']][$dia])): $conteo = count($matriz[$hora['idnum']][$dia]); if ($conteo > 0): ?><div class="contador"><?= $conteo ?></div><?php endif; ?>
                                    <?php foreach ($matriz[$hora['idnum']][$dia] as $a): ?>
                                        <div class="mini-asignacion" onclick="event.stopPropagation(); verDetalleAsignacion(<?= $a['id_asignacion'] ?>)" title="<?= htmlspecialchars($a['txt_asignatura']) . ' - ' . htmlspecialchars($a['nombre_completo']) ?>"><?= htmlspecialchars(substr($a['txt_asignatura'], 0, 15)) ?>...</div>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>

        <?php include '../views/layout/footer.php'; ?>
    </div>

    <script src="../public/js/indhorario.js"></script>
</body>
</html>