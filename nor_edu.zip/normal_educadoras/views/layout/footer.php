<footer style="text-align: center; padding: 25px; background: linear-gradient(145deg, #1f2937, #374151); border-top: 1px solid rgba(255, 255, 255, 0.1); color: white; margin-top: 40px; position: relative;">
    <div style="position: absolute; top: 0; left: 0; width: 100%; height: 3px; background: linear-gradient(90deg, #dc2626, #1f2937, #dc2626);"></div>
    <div style="position: relative; z-index: 1; font-weight: 500; letter-spacing: 0.5px;">
        © 2026 Escuela Normal Federal de Educadoras Maestra Estefanía Castañeda | Todos los derechos reservados
    </div>
    <div style="margin-top: 10px; font-size: 0.9rem; opacity: 0.8;">
        Nuestras vidas dedicadas a la niñez
    </div>
</footer>