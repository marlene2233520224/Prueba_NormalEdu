<header>
    <div style="
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 18px 35px;
        background: linear-gradient(135deg, 
            rgba(31, 41, 55, 0.98) 0%, 
            rgba(55, 65, 81, 0.95) 50%,
            rgba(31, 41, 55, 0.98) 100%);
        backdrop-filter: blur(10px);
        border-bottom: 3px solid rgba(220, 38, 38, 0.7);
        box-shadow: 
            0 8px 32px rgba(0, 0, 0, 0.4),
            inset 0 1px 0 rgba(255, 255, 255, 0.1);
        color: white;
        position: relative;
        overflow: hidden;
    ">

        <div style="display: flex; align-items: center; gap: 30px;">
            <div style="
                position: relative;
                padding: 3px;
                background: linear-gradient(135deg, 
                    rgba(255,255,255,0.1), 
                    rgba(255,255,255,0));
                border-radius: 15px;
            ">
                <div style="
                    padding: 12px;
                    background: linear-gradient(145deg, #ffffff, #f9fafb);
                    border-radius: 12px;
                    box-shadow: 
                        0 8px 25px rgba(0, 0, 0, 0.4),
                        0 0 0 1px rgba(255, 255, 255, 0.1);
                ">
                    <img src="../public/images/logo.png" alt="Logo" 
                         style="height: 75px; display: block; filter: contrast(1.1);">
                </div>
            </div>
            
            <div>
                <div style="
                    font-size: 14px;
                    color: #ffffffff;
                    letter-spacing: 1.5px;
                    text-transform: uppercase;
                    margin-bottom: 5px;
                    font-weight: 500;
                ">
                    Escuela Normal Federal de Educadoras
                </div>
                <div style="
                    font-size: 24px;
                    font-weight: 700;
                    background: linear-gradient(90deg, #ffffff, #f0f0f0);
                    -webkit-background-clip: text;
                    -webkit-text-fill-color: transparent;
                    background-clip: text;
                    text-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
                    letter-spacing: -0.5px;
                ">
                    Maestra Estefanía Castañeda
                </div>
            </div>
        </div>
        
        <div style="
            position: relative;
            z-index: 2;
            background: rgba(31, 41, 55, 0.7);
            border: 1px solid rgba(255, 255, 255, 0.08);
            border-radius: 10px;
            padding: 12px 20px;
            backdrop-filter: blur(5px);
            box-shadow: 
                0 4px 12px rgba(0, 0, 0, 0.2),
                inset 0 1px 0 rgba(255, 255, 255, 0.05);
        ">
            <div style="
                font-size: 12px;
                color: #9ca3af;
                margin-bottom: 3px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
            ">
                Bienvenido
            </div>
            <div style="
                font-size: 16px;
                font-weight: 600;
                color: white;
                display: flex;
                align-items: center;
                gap: 8px;
            ">
                <div style="
                    width: 6px;
                    height: 6px;
                    background: #10b981;
                    border-radius: 50%;
                    animation: pulse 2s infinite;
                "></div>
                <?= $_SESSION['user']['usuario'] ?>
            </div>
        </div>
    </div>
    
    <style>
        @keyframes pulse {
            0%, 100% { opacity: 1; }
            50% { opacity: 0.5; }
        }
    </style>
</header>