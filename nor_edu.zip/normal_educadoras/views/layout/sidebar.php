<aside class="sidebar">
    <nav class="sidebar-nav">
        <div class="nav-section">
            <span class="section-label">NAVEGACIÓN PRINCIPAL</span>
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../controllers/DashboardController.php" class="nav-link">
                        <span class="link-text">Inicio</span>
                        <div class="link-indicator"></div>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../controllers/HorariosController.php" class="nav-link">
                        <span class="link-text">Horarios</span>
                        <div class="link-indicator"></div>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../controllers/GruposController.php" class="nav-link">
                        <span class="link-text">Grupos</span>
                        <div class="link-indicator"></div>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="../controllers/ReportesController.php" class="nav-link">
                        <span class="link-text">Reportes</span>
                        <div class="link-indicator"></div>
                    </a>
                </li>
            </ul>
        </div>

        <div class="logout-container">
            <ul class="nav-menu">
                <li class="nav-item">
                    <a href="../controllers/AuthController.php?action=logout" class="nav-link logout-link">
                        <i class="fas fa-sign-out-alt"></i>
                        <span class="link-text">Cerrar Sesión</span>
                        <div class="link-indicator"></div>
                    </a>
                </li>
            </ul>
        </div>
    </nav>
</aside>

<link rel="stylesheet" href="../public/css/sidebar.css">
<script src="../public/js/sidebar.js" defer></script>