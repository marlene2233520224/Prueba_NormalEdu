<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Docente - <?php echo $nombre_docente; ?></title>
    <link rel="stylesheet" href="../public/css/style.css">
    <style>
        .reporte-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .info-box {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .info-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            flex: 1;
            min-width: 200px;
            text-align: center;
        }

        .info-card h3 {
            font-size: 1.2rem;
            color: var(--color-gris);
            margin-bottom: 10px;
        }

        .info-card p {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--color-rojo);
        }

        .ciclo-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .ciclo-info p {
            margin: 5px 0;
            color: #555;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .table th,
        .table td {
            text-align: left;
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
        }

        .table th {
            background-color: var(--color-gris);
            color: white;
            position: sticky;
            top: 0;
        }

        .table tr:nth-child(even) {
            background-color: var(--color-gris-claro);
        }

        .table tr:hover {
            background-color: #e0e0e0;
        }

        .print-btn, .btn-secondary {
            background-color: var(--color-gris);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
        }

        .print-btn:hover, .btn-secondary:hover {
            background-color: var(--color-gris-medio);
        }

        .btn-secondary {
            background-color: #6c757d;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        .no-data {
            text-align: center;
            padding: 40px;
            color: #666;
            font-size: 1.1em;
        }

        @media print {
            .actions, .btn {
                display: none;
            }
            
            .table th {
                background-color: #555;
                color: white;
            }
            
            body {
                font-family: Arial, sans-serif;
                color: #000;
            }
            
            .info-card {
                border: 1px solid #ccc;
                box-shadow: none;
            }
            
            .table {
                border: 1px solid #000;
            }
            
            .table td {
                border: 1px solid #ddd;
            }
        }
    </style>
</head>
<body>
    <?php include '../views/layout/sidebar.php'; ?>

    <div class="main-content">
        <?php include '../views/layout/header.php'; ?>
        
        <div class="reporte-header">
            <div>
                <h1>Reporte de Docente: <?php echo $nombre_docente; ?></h1>
                <div class="ciclo-info">
                    <p><strong>Ciclo Escolar:</strong> <?php echo $ciclo['txt_ciclo_escolar']; ?></p>
                    <p><strong>Clave:</strong> <?php echo $docente['clave_docente']; ?></p>
                </div>
            </div>
            <div class="actions">
                <button class="print-btn" onclick="window.print()">Imprimir</button>
                <a href="seleccion-reporte.php" class="btn-secondary">Nuevo Reporte</a>
                <a href="index.php" class="btn-secondary">Volver al Inicio</a>
            </div>
        </div>

        <div class="info-box">
            <div class="info-card">
                <h3>Horas Asignadas</h3>
                <p><?php echo round($total_horas, 1); ?></p>
            </div>
            <div class="info-card">
                <h3>Grupos Asignados</h3>
                <p><?php echo count($grupos_asignados); ?></p>
            </div>
            <div class="info-card">
                <h3>Asignaturas</h3>
                <p><?php echo count($asignaturas_asignadas); ?></p>
            </div>
            <div class="info-card">
                <h3>Conflictos</h3>
                <p>0</p>
            </div>
        </div>

        <?php if (count($horarios) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Día</th>
                        <th>Hora</th>
                        <th>Plan</th>
                        <th>Asignatura</th>
                        <th>Clave</th>
                        <th>Grupo</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($horarios as $horario): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($horario['dia']); ?></td>
                            <td><?php echo htmlspecialchars($horario['hora']); ?></td>
                            <td><?php echo htmlspecialchars($horario['plan']); ?></td>
                            <td><?php echo htmlspecialchars($horario['asignatura']); ?></td>
                            <td><?php echo htmlspecialchars($horario['clave_asignatura']); ?></td>
                            <td><?php echo htmlspecialchars($horario['grupo']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-data">
                <h3>No hay asignaciones registradas para este docente en el ciclo seleccionado</h3>
                <p>El docente no tiene horarios asignados para el ciclo escolar <?php echo $ciclo['txt_ciclo_escolar']; ?></p>
            </div>
        <?php endif; ?>

        <?php include '../views/layout/footer.php'; ?>
    </div>
</body>
</html>