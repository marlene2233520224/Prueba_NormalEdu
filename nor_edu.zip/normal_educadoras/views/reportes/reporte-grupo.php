<?php
// Conexión a la base de datos
$conn = new mysqli("127.0.0.1", "root", "", "horarios_db");

if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Obtener parámetros
$id_ciclo = isset($_GET['ciclo']) ? $_GET['ciclo'] : '';
$id_plan = isset($_GET['plan']) ? $_GET['plan'] : '';
$grado = isset($_GET['grado']) ? $_GET['grado'] : '';
$grupo = isset($_GET['grupo']) ? $_GET['grupo'] : '';

// Validar parámetros
if (!$id_ciclo || !$id_plan || !$grado || !$grupo) {
    header("Location: seleccion-reporte.php");
    exit();
}

// Obtener información del ciclo
$sql_ciclo = "SELECT * FROM cat_ciclo_escolar WHERE id_ciclo_escolar = ?";
$stmt = $conn->prepare($sql_ciclo);
$stmt->bind_param("i", $id_ciclo);
$stmt->execute();
$result_ciclo = $stmt->get_result();
$ciclo = $result_ciclo->fetch_assoc();

// Obtener información del plan
$sql_plan = "SELECT * FROM cat_plan_estudio WHERE id_plan = ?";
$stmt = $conn->prepare($sql_plan);
$stmt->bind_param("i", $id_plan);
$stmt->execute();
$result_plan = $stmt->get_result();
$plan = $result_plan->fetch_assoc();

// Obtener asignaciones del grupo
$sql_asignaciones = "
    SELECT ca.*, ca2.txt_asignatura, cd.txt_nombre, cd.txt_paterno, cd.txt_materno
    FROM ctrl_asignacion ca
    INNER JOIN cat_asignaturas ca2 ON ca.clave_asignatura = ca2.clave_asignatura
    INNER JOIN cat_docente cd ON ca.clave_docente = cd.clave_docente
    WHERE ca.id_ciclo_escolar = ?
    AND ca.id_plan_estudio = ?
    AND ca.grado = ?
    AND ca.grupo = ?
    AND ca.id_status = 1
    ORDER BY ca.clave_asignatura
";

$stmt = $conn->prepare($sql_asignaciones);
$stmt->bind_param("iiis", $id_ciclo, $id_plan, $grado, $grupo);
$stmt->execute();
$result_asignaciones = $stmt->get_result();

// Obtener horarios detallados
$horarios_grupo = [];
$docentes_grupo = [];
$asignaturas_grupo = [];

while($asignacion = $result_asignaciones->fetch_assoc()) {
    $id_asignacion = $asignacion['id_asignacion'];
    $nombre_docente = $asignacion['txt_nombre'] . ' ' . $asignacion['txt_paterno'] . ' ' . $asignacion['txt_materno'];
    
    // Obtener detalle de horarios
    $sql_detalle = "
        SELECT cad.*, h.horas 
        FROM ctrl_asignacion_detalle2 cad
        INNER JOIN horas h ON cad.id_hora = h.idnum
        WHERE cad.id_asignacion = ?
        AND cad.id_status = 1
        ORDER BY 
            CASE cad.dia_semana
                WHEN 'Lunes' THEN 1
                WHEN 'Martes' THEN 2
                WHEN 'Miércoles' THEN 3
                WHEN 'Jueves' THEN 4
                WHEN 'Viernes' THEN 5
                ELSE 6
            END,
            cad.id_hora
    ";
    
    $stmt2 = $conn->prepare($sql_detalle);
    $stmt2->bind_param("i", $id_asignacion);
    $stmt2->execute();
    $result_detalle = $stmt2->get_result();
    
    while($detalle = $result_detalle->fetch_assoc()) {
        $horarios_grupo[] = [
            'dia' => $detalle['dia_semana'],
            'hora' => $detalle['horas'],
            'asignatura' => $asignacion['txt_asignatura'],
            'docente' => $nombre_docente,
            'clave_asignatura' => $asignacion['clave_asignatura']
        ];
    }
    
    // Registrar docentes y asignaturas únicos
    if (!in_array($nombre_docente, $docentes_grupo)) {
        $docentes_grupo[] = $nombre_docente;
    }
    
    if (!in_array($asignacion['txt_asignatura'], $asignaturas_grupo)) {
        $asignaturas_grupo[] = $asignacion['txt_asignatura'];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reporte de Grupo <?php echo $grado . $grupo; ?></title>
    <link rel="stylesheet" href="../public/css/style.css">
    <style>
        /* Estilos similares al reporte de docente */
        .reporte-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .actions {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }

        .info-box {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
            flex-wrap: wrap;
        }

        .info-card {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 5px rgba(0,0,0,0.05);
            flex: 1;
            min-width: 200px;
            text-align: center;
        }

        .info-card h3 {
            font-size: 1.2rem;
            color: var(--color-gris);
            margin-bottom: 10px;
        }

        .info-card p {
            font-size: 1.8rem;
            font-weight: bold;
            color: var(--color-rojo);
        }

        .grupo-info {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .grupo-info p {
            margin: 5px 0;
            color: #555;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }

        .table th,
        .table td {
            text-align: left;
            padding: 12px 15px;
            border-bottom: 1px solid #ddd;
        }

        .table th {
            background-color: var(--color-gris);
            color: white;
        }

        .table tr:nth-child(even) {
            background-color: var(--color-gris-claro);
        }

        .table tr:hover {
            background-color: #e0e0e0;
        }

        .print-btn, .btn-secondary {
            background-color: var(--color-gris);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            cursor: pointer;
            font-weight: 600;
            text-decoration: none;
            display: inline-block;
        }

        .print-btn:hover, .btn-secondary:hover {
            background-color: var(--color-gris-medio);
        }

        .btn-secondary {
            background-color: #6c757d;
        }

        .no-data {
            text-align: center;
            padding: 40px;
            color: #666;
            font-size: 1.1em;
        }
    </style>
</head>
<body>
    <?php include '../views/layout/sidebar.php'; ?>

    <div class="main-content">
        <?php include '../views/layout/header.php'; ?>
        
        <div class="reporte-header">
            <div>
                <h1>Reporte del Grupo: <?php echo $grado . $grupo; ?></h1>
                <div class="grupo-info">
                    <p><strong>Ciclo Escolar:</strong> <?php echo $ciclo['txt_ciclo_escolar']; ?></p>
                    <p><strong>Plan de Estudios:</strong> <?php echo $plan['txt_plan']; ?></p>
                    <p><strong>Grado y Grupo:</strong> <?php echo $grado . ' - ' . $grupo; ?></p>
                </div>
            </div>
            <div class="actions">
                <button class="print-btn" onclick="window.print()">Imprimir</button>
                <a href="seleccion-reporte.php" class="btn-secondary">Nuevo Reporte</a>
                <a href="index.php" class="btn-secondary">Volver al Inicio</a>
            </div>
        </div>

        <div class="info-box">
            <div class="info-card">
                <h3>Total de Horas</h3>
                <p><?php echo count($horarios_grupo); ?></p>
            </div>
            <div class="info-card">
                <h3>Docentes</h3>
                <p><?php echo count($docentes_grupo); ?></p>
            </div>
            <div class="info-card">
                <h3>Asignaturas</h3>
                <p><?php echo count($asignaturas_grupo); ?></p>
            </div>
            <div class="info-card">
                <h3>Asignaciones</h3>
                <p><?php echo $result_asignaciones->num_rows; ?></p>
            </div>
        </div>

        <?php if (count($horarios_grupo) > 0): ?>
            <table class="table">
                <thead>
                    <tr>
                        <th>Día</th>
                        <th>Hora</th>
                        <th>Asignatura</th>
                        <th>Clave</th>
                        <th>Docente</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($horarios_grupo as $horario): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($horario['dia']); ?></td>
                            <td><?php echo htmlspecialchars($horario['hora']); ?></td>
                            <td><?php echo htmlspecialchars($horario['asignatura']); ?></td>
                            <td><?php echo htmlspecialchars($horario['clave_asignatura']); ?></td>
                            <td><?php echo htmlspecialchars($horario['docente']); ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="no-data">
                <h3>No hay asignaciones registradas para este grupo</h3>
                <p>El grupo <?php echo $grado . $grupo; ?> no tiene horarios asignados para el ciclo escolar seleccionado</p>
            </div>
        <?php endif; ?>

        <?php include '../views/layout/footer.php'; ?>
    </div>
</body>
</html>