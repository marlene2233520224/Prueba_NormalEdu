<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seleccionar Reporte</title>
    <link rel="stylesheet" href="../public/css/style.css">
    <style>
        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 20px;
        }
        
        .card {
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
        }
        
        select, input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 16px;
        }
        
        .btn {
            background-color: var(--color-rojo);
            color: white;
            padding: 12px 30px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
        }
        
        .btn:hover {
            background-color: #c82333;
        }
        
        .reporte-options {
            display: flex;
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .option-btn {
            flex: 1;
            padding: 20px;
            text-align: center;
            background: #f8f9fa;
            border: 2px solid #dee2e6;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s;
        }
        
        .option-btn.active {
            background: var(--color-rojo);
            color: white;
            border-color: var(--color-rojo);
        }
        
        .hidden {
            display: none;
        }
    </style>
</head>
<body>
    <?php include '../views/layout/sidebar.php'; ?>
    
    <div class="main-content">
        <?php include '../views/layout/header.php'; ?>
        
        <div class="container">
            <h1>Generar Reporte</h1>
            
            <div class="reporte-options">
                <div class="option-btn active" onclick="showForm('docente')">Por Docente</div>
                <div class="option-btn" onclick="showForm('grupo')">Por Grupo</div>
            </div>
            
            <!-- Formulario para reporte por docente -->
            <form id="form-docente" action="reporte-docente.php" method="GET">
                <div class="card">
                    <h2>Reporte por Docente</h2>
                    <div class="form-group">
                        <label for="ciclo_docente">Ciclo Escolar:</label>
                        <select id="ciclo_docente" name="ciclo" required>
                            <option value="">Seleccionar ciclo</option>
                            <?php
                            // Conexión a la base de datos
                            $conn = new mysqli("127.0.0.1", "root", "", "horarios_db");
                            
                            if ($conn->connect_error) {
                                die("Error de conexión: " . $conn->connect_error);
                            }
                            
                            // Obtener ciclos escolares
                            $sql = "SELECT * FROM cat_ciclo_escolar WHERE id_status = 1 ORDER BY txt_ciclo_escolar DESC";
                            $result = $conn->query($sql);
                            
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='{$row['id_ciclo_escolar']}'>{$row['txt_ciclo_escolar']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="docente">Docente:</label>
                        <select id="docente" name="docente" required>
                            <option value="">Seleccionar docente</option>
                            <?php
                            // Obtener docentes
                            $sql = "SELECT * FROM cat_docente WHERE id_status = 1 ORDER BY txt_paterno, txt_materno, txt_nombre";
                            $result = $conn->query($sql);
                            
                            while($row = $result->fetch_assoc()) {
                                $nombre = $row['txt_paterno'] . ' ' . $row['txt_materno'] . ' ' . $row['txt_nombre'];
                                echo "<option value='{$row['clave_docente']}'>{$nombre}</option>";
                            }
                            
                            $conn->close();
                            ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn">Generar Reporte</button>
                </div>
            </form>
            
            <!-- Formulario para reporte por grupo -->
            <form id="form-grupo" action="reporte-grupo.php" method="GET" class="hidden">
                <div class="card">
                    <h2>Reporte por Grupo</h2>
                    <div class="form-group">
                        <label for="ciclo_grupo">Ciclo Escolar:</label>
                        <select id="ciclo_grupo" name="ciclo" required>
                            <option value="">Seleccionar ciclo</option>
                            <?php
                            $conn = new mysqli("127.0.0.1", "root", "", "horarios_db");
                            $sql = "SELECT * FROM cat_ciclo_escolar WHERE id_status = 1 ORDER BY txt_ciclo_escolar DESC";
                            $result = $conn->query($sql);
                            
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='{$row['id_ciclo_escolar']}'>{$row['txt_ciclo_escolar']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="plan">Plan de Estudios:</label>
                        <select id="plan" name="plan" required>
                            <option value="">Seleccionar plan</option>
                            <?php
                            $sql = "SELECT * FROM cat_plan_estudio WHERE id_status = 1";
                            $result = $conn->query($sql);
                            
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='{$row['id_plan']}'>{$row['txt_plan']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="grado">Grado:</label>
                        <select id="grado" name="grado" required>
                            <option value="">Seleccionar grado</option>
                            <?php
                            $sql = "SELECT DISTINCT grado FROM grado ORDER BY grado";
                            $result = $conn->query($sql);
                            
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='{$row['grado']}'>{$row['grado']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    
                    <div class="form-group">
                        <label for="grupo">Grupo:</label>
                        <select id="grupo" name="grupo" required>
                            <option value="">Seleccionar grupo</option>
                            <?php
                            $sql = "SELECT DISTINCT grupo FROM grupo ORDER BY grupo";
                            $result = $conn->query($sql);
                            
                            while($row = $result->fetch_assoc()) {
                                echo "<option value='{$row['grupo']}'>{$row['grupo']}</option>";
                            }
                            $conn->close();
                            ?>
                        </select>
                    </div>
                    
                    <button type="submit" class="btn">Generar Reporte</button>
                </div>
            </form>
        </div>
    </div>
    
    <script>
        function showForm(type) {
            // Actualizar botones activos
            document.querySelectorAll('.option-btn').forEach(btn => {
                btn.classList.remove('active');
            });
            event.target.classList.add('active');
            
            // Mostrar/ocultar formularios
            if (type === 'docente') {
                document.getElementById('form-docente').classList.remove('hidden');
                document.getElementById('form-grupo').classList.add('hidden');
            } else {
                document.getElementById('form-docente').classList.add('hidden');
                document.getElementById('form-grupo').classList.remove('hidden');
            }
        }
    </script>
</body>
</html>